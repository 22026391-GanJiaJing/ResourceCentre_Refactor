function myFun(){
    alert("Hello JavaScript");
}